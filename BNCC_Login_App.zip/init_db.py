import sqlite3

conn = sqlite3.connect("users.db")
c = conn.cursor()
c.execute("CREATE TABLE users (id TEXT, name TEXT, unit TEXT, rank TEXT)")
c.execute("INSERT INTO users VALUES ('1001', 'Rahim', 'Dhaka', 'Cadet')")
conn.commit()
conn.close()