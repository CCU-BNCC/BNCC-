from flask import Flask, request, render_template, redirect
import sqlite3

app = Flask(__name__)

def get_user(user_id):
    con = sqlite3.connect("users.db")
    cur = con.cursor()
    cur.execute("SELECT * FROM users WHERE id=?", (user_id,))
    user = cur.fetchone()
    con.close()
    return user

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user_id = request.form["id"]
        user = get_user(user_id)
        if user:
            return render_template("dashboard.html", user=user)
        return "Invalid ID"
    return render_template("login.html")

@app.route("/admin")
def admin():
    con = sqlite3.connect("users.db")
    cur = con.cursor()
    cur.execute("SELECT * FROM users")
    users = cur.fetchall()
    con.close()
    return render_template("admin.html", users=users)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)